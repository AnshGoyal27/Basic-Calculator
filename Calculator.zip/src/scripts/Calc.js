import { Output } from "./Output"
import { Button } from "./Button"
import { useState } from "react"
export const Calc=()=>{
    const [Bracks,Cbracks]=useState(0);

    const operationlist=['+','-','*','/'];

    const [Input,Cinput]=useState("")

    function number(no){
        if(Input==="Error"){
            Cinput(""+no);
        }
        else{
            Cinput(Input+no);  
        }
        
    }
    function clear(){
        Cinput("");
    }
    function operation(op){
        if(Input==="Error"){
            
        }
        else if(op!=='-' && (Input==="" || (operationlist.includes(Input[0]) && Input.length===1) || Input[Input.length-1]==='(')){
            
        }
        else if(operationlist.includes(Input[(Input.length)-1])){
            Cinput(Input.slice(0,Input.length-1)+op);
        }
        else{
            Cinput(Input+op);
        }
    }
    function calculate(){
        try{
            Cinput(eval(Input));
        }
        catch(err){
            Cinput("Error");
            Cbracks(0);
        }
        
    }
    function lastremove(){
        if(Input==="Error"){
            Cinput("");
        }
        else{
            Cinput(Input.slice(0,Input.length-1));
        }
        
    }

    function brackets(br){
        if(br===')'){
            if(Bracks>0 && (!isNaN(Input[(Input.length)-1]) || Input[(Input.length)-1]==='(')){
                Cbracks(Bracks-1)
                Cinput(Input+br);
            }
            
        }
        else{
            if(!isNaN(Input[(Input.length)-1])){}
            else if(Input==="Error"){}
            else{
                Cbracks(Bracks+1);
                Cinput(Input+br);
            }
           
            
        }
    }

    return(
        <div>
        <Output ToSolve={Input}></Output>
            <table>
                <tbody>
                    <tr>
                        <td><Button Title="1" itype={number}></Button></td>
                        <td><Button Title="2" itype={number}></Button></td>
                        <td><Button Title="3" itype={number}></Button></td>
                        <td><Button Title="4" itype={number}></Button></td>
                    </tr>
                    <tr>
                        <td><Button Title="5" itype={number}></Button></td>
                        <td><Button Title="6" itype={number}></Button></td>
                        <td><Button Title="7" itype={number}></Button></td>
                        <td><Button Title="8" itype={number}></Button></td>
                    </tr>
                    <tr>
                        <td><Button Title="C" itype={clear}></Button></td>
                        <td><Button Title="9" itype={number}></Button></td>
                        <td><Button Title="0" itype={number}></Button></td>
                        <td><Button Title="=" itype={calculate}></Button></td>
                    </tr>
                    <tr>
                        <td><Button Title="+" itype={operation}></Button></td>
                        <td><Button Title="-" itype={operation}></Button></td>
                        <td><Button Title="*" itype={operation}></Button></td>
                        <td><Button Title="/" itype={operation}></Button></td>
                    </tr>
                    <tr>
                        <td><Button Title="<-" itype={lastremove}></Button></td>
                        <td><Button Title="(" itype={brackets}></Button></td>
                        <td><Button Title=")" itype={brackets}></Button></td>
                    </tr>
                </tbody>
            </table>

        </div>
    )
}