import {TextField } from "@mui/material"

export const Output=({ToSolve})=>{
    
    return(
        <TextField disabled className="bg-light" value={ToSolve}></TextField>
    )
}