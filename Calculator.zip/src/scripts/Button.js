export const Button=({Title,itype})=>{
    const margin={
        "marginTop": "1px",
        "marginBottom": "1px",
        "marginRight": "1px",
        "marginLeft": "1px",
        "width":"50px"
      }
    function action(){
        itype(Title);
    }
    return(<button type="button" className="btn btn-primary btn-lg" style={margin} onClick={action}>{Title}</button>)
}