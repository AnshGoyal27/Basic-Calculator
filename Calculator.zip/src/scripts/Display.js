import { Calc } from "./Calc";

export const Display=()=>{
    
    return(
    <>
        <h1 className="bg-primary text-light text-center">Calculator</h1>
        <Calc className="" ></Calc>
    </>);
}