import './App.css';
import { Display } from './scripts/Display';

function App() {
  return (
    <>
      <Display></Display>
    </>
  );
}

export default App;
